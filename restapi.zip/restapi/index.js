const express =require("express");
// const { route } = require("express/lib/application");

const app =express();
app.use(name)


app.get("/books", name ,(req, res)=>{
    return res.send({route:"books"})
})

function name(req, res, next){
    return res.send({route:"rashmirathi"});
    next()
    // return res.send({route:"mahabharat"});
}



app.listen(5000, ()=>{
    console.log("running at 5000...!!!")
});
